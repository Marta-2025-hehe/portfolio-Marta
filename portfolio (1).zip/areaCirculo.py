""""3. Calcular el área de un circulo. Diseñar un programa permita obtener el área de una 
circunferencia a partir de su radio. El programa deberá solicitar al usuario por consola el radio 
del círculo, y mostrar por pantalla el resultado del cálculo. """

import tkinter as tk
from tkinter import messagebox
import math

# Función para calcular el área
def calcular_area():
    try:
        radio = float(entry_radio.get())
        if radio <= 0
            raise ValueError("El radio debe ser mayor a cero.")
        area = math.pi * radio ** 2
        resultado.set(f"🟠 Área del círculo: {area:.2f} cm²")
    except ValueError as ve:
        messagebox.showerror("Error", str(ve))

# Ventana principal
ventana = tk.Tk()
ventana.title("Calculadora de Área de un Círculo")
ventana.geometry("350x180")
ventana.resizable(False, False)

# Widgets
tk.Label(ventana, text="Introduce el radio (cm):").pack(pady=5)
entry_radio = tk.Entry(ventana)
entry_radio.pack()

tk.Button(ventana, text="Calcular Área", command=calcular_area).pack(pady=10)

resultado = tk.StringVar()
tk.Label(ventana, textvariable=resultado, font=("Arial", 12, "bold")).pack(pady=5)

# Iniciar app
ventana.mainloop()

""""resolucion comentada:
import tkinter as tk                # Importa la librería tkinter para la interfaz gráfica
from tkinter import messagebox      # Importa el módulo para mostrar ventanas emergentes (alertas)
import math                         # Importa la librería math, que tiene π (pi) y otras funciones matemáticas
python

# Función que calcula el área del círculo
def calcular_area():
    try:
        radio = float(entry_radio.get())  # Lee el valor escrito en la caja de texto y lo convierte a número
        if radio <= 0:
            raise ValueError("El radio debe ser mayor a cero.")  # Valida que el radio sea positivo

        area = math.pi * radio ** 2       # Aplica la fórmula del área del círculo: A = π * r²
        resultado.set(f"🟠 Área del círculo: {area:.2f} cm²")  # Muestra el resultado con 2 decimales
    except ValueError as ve:
        messagebox.showerror("Error", str(ve))  # Muestra un mensaje de error si el input no es válido
python

# Crear la ventana principal
ventana = tk.Tk()                         # Crea la ventana principal
ventana.title("Calculadora de Área de un Círculo")  # Título de la ventana
ventana.geometry("350x180")              # Tamaño de la ventana (ancho x alto)
ventana.resizable(False, False)          # Evita que el usuario cambie el tamaño de la ventana
python

# Etiqueta para el input
tk.Label(ventana, text="Introduce el radio (cm):").pack(pady=5)  # Texto explicativo encima de la caja de entrada

entry_radio = tk.Entry(ventana)         # Crea la caja de entrada donde el usuario pondrá el radio
entry_radio.pack()                      # Muestra la caja en la ventana
python

# Botón que llama a la función calcular_area al hacer clic
tk.Button(ventana, text="Calcular Área", command=calcular_area).pack(pady=10)
python

# Variable para mostrar el resultado
resultado = tk.StringVar()              # Crea una variable especial para mostrar texto en la interfaz
tk.Label(ventana, textvariable=resultado, font=("Arial", 12, "bold")).pack(pady=5)  # Muestra el resultado en pantalla
python

# Inicia la aplicación gráfica
ventana.mainloop()                      # Arranca el bucle principal de Tkinter (hace que la ventana se mantenga abierta)
🧠 Resumen de los conceptos clave:
Comando	¿Qué hace?
tk.Tk()	Crea la ventana principal
tk.Entry()	Crea una caja de entrada de texto
entry.get()	Obtiene el valor que el usuario escribió
tk.Button()	Crea un botón que ejecuta una función
tk.Label()	Muestra texto en la ventana
tk.StringVar()	Variable especial para actualizar texto en tiempo real
math.pi	Constante π = 3.14159...
.pack()	Organiza los elementos en la ventana (de arriba hacia abajo)
messagebox.showerror()	Muestra un popup de error si el input es inválido"""
