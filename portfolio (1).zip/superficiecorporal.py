"""1.Superficie corporal de una persona. Realizar un programa en C capaz de estimar la superficie 
corporal de una persona. Se empleará la siguiente fórmula: 
Donde: 
x -> es la superficie corporal de la persona. 
Peso -> es el peso de la persona. 
Altura -> es la altura de la persona. 
El programa deberá permitir al usuario introducir los datos por consola de peso y altura, 
realizar el cálculo y mostrar los resultados por pantalla."""

import tkinter as tk
from tkinter import messagebox
import math

# Función para calcular la superficie corporal
def calcular_superficie():
    try:
        peso = float(entry_peso.get())
        altura = float(entry_altura.get())
        
        # Validación rápida
        if peso <= 0 or altura <= 0:
            raise ValueError("Los valores deben ser positivos.")

        superficie_m2 = math.sqrt((peso * altura) / 3600)
        superficie_cm2 = superficie_m2 * 10000

        resultado.set(f"✅ Superficie corporal: {superficie_cm2:.2f} cm²")
    except ValueError as ve:
        messagebox.showerror("Error de entrada", str(ve))

# Crear ventana principal
ventana = tk.Tk()
ventana.title("Calculadora de Superficie Corporal")
ventana.geometry("350x200")
ventana.resizable(False, False)

# Widgets
tk.Label(ventana, text="Peso (kg):").pack(pady=5)
entry_peso = tk.Entry(ventana)
entry_peso.pack()

tk.Label(ventana, text="Altura (cm):").pack(pady=5)
entry_altura = tk.Entry(ventana)
entry_altura.pack()

tk.Button(ventana, text="Calcular", command=calcular_superficie).pack(pady=10)

resultado = tk.StringVar()
tk.Label(ventana, textvariable=resultado, font=("Arial", 12, "bold")).pack()

# Iniciar loop de la app
ventana.mainloop()


