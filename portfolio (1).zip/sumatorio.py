
 # Suma de los 200 primeros números impares con lazo for:

"""suma = 0
for i in range(200):
    numero_impar = 2 * i + 1  
    suma += numero_impar

print(f"La suma de los 200 primeros números impares es: {suma}")"""

# Suma de los 200 primeros números impares con while:
suma = 0
contador = 0
numero = 1

while contador < 200:
    suma += numero
    numero += 2  
    contador += 1

print(f"La suma de los 200 primeros números impares es: {suma}")

