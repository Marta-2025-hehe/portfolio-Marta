# Ventana gráfica dedicada al profe, con mensaje legendario
# Alumna: Marta Glez. Lamas 😎

import tkinter as tk

# Crear la ventana
ventana = tk.Tk()
ventana.title("Mensaje para el profe 💡")
ventana.geometry("600x200")
ventana.configure(bg="#fff0f5")  # Fondo pastel rosita, vibra zodiacal

# Mensaje personalizado estilo pancarta
mensaje = tk.Label(
    ventana,
    text="PROFE, AUNQUE SEAS VIRGO, ERES EL MEJOR!!!!",
    font=("Comic Sans MS", 16, "bold"),
    fg="#4B0082",
    bg="#fff0f5",
    wraplength=550,
    justify="center"
)
mensaje.pack(expand=True)

# Emoji extra (opcional)
emoji = tk.Label(
    ventana,
    text="💫📚👏",
    font=("Arial", 24),
    bg="#fff0f5"
)
emoji.pack()

# Ejecutar ventana
ventana.mainloop()

