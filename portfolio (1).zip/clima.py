
import requests
#"https://www.meteosource.com/api/v1/free/point?place_id=london&sections=all&timezone=UTC&language=en&units=metric&key=93qbsbum54hh77sjgpnny7lhbzzuq2rni13thax8"
#ciudad="Vigo"
api_key = "93qbsbum54hh77sjgpnny7lhbzzuq2rni13thax8"
domain_url="https://www.meteosource.com/api/v1/free/point?place_id="
url_2="&sections=all&timezone=UTC&language=en&units=metric&key="

def consultar_clima(ciudad):
    
    url = domain_url+ciudad+url_2+api_key
    api_call = requests.get(url)
    if api_call.status_code == 200:
        respuesta = api_call.json()
                
        print(f"Datos del tiempo en {ciudad}")
        print(respuesta["current"])
        print("Resumen: ", respuesta["current"]["summary"])
        print("Temperatura: ", respuesta["current"]["temperature"])
        """
        for clave_clima, datos_clima in respuesta["current"].items():
            #print(type(clave_clima),type(datos_clima))
            print(clave_clima, datos_clima)
        """          
    else:
        print(f"Request failed with status code: {api_call.status_code}")
        

        
def main():
    ciudad = input("Que ciudad quieres consultar: ")
    consultar_clima(ciudad)
main()